# SPDX-License-Identifier: GPL-3.0-or-later

"""
Isekai Asset Studio — MobilisFrontier XR Pipeline
================================================
Blender 5.1 Extension

目的:
    Blender上でモデルにAIエージェントプロファイル（役割・行動指示）を付与し、
    UnityのVR空間へ自律駆動するAIエージェントとして
    ゼロコーディングでデプロイするパイプラインを提供する。

依存ライブラリ:
    標準ライブラリ（urllib.request, json, os, tempfile）のみを使用。
    外部パッケージ（requests等）は一切不使用。

アーキテクチャ:
    ┌───────────────────────────────────────────────┐
    │ IsekaiProperties  (PropertyGroup)              │
    │   - operation_mode: Enum('GENERATE'|'EXPORT') │
    │   - role: String                              │
    │   - directive: String                         │
    └───────────────────────────────────────────────┘
              │
    ┌─────────┴──────────┐
    │                    │
    ▼                    ▼
GENERATE モード      EXPORT モード
ISEKAI_OT_generate   ISEKAI_OT_export_to_unity
  ↓ ダウンロード       ↓ JSON + FBX → Unity
  ↓ PBRノード構築
"""

import bpy
import json
import os
import tempfile
import urllib.request
import urllib.parse
import urllib.error

from bpy.props import EnumProperty, StringProperty, PointerProperty
from bpy.types import Panel, Operator, PropertyGroup, AddonPreferences

# ============================================================
# 定数定義
# ============================================================

# テクスチャ生成用ダミー画像URL（Pexels: CCライセンスフリー素材）
DUMMY_TEXTURE_URL = (
    "https://images.pexels.com/photos/1010496/pexels-photo-1010496.jpeg"
    "?auto=compress&cs=tinysrgb&w=600"
)

# .blend ファイル基準からの Unity AutoImport フォルダへの相対パス
# 構成想定: IsekaiPipeline_Project/
#   ├── <scene>.blend  (Blender作業ファイル)
#   └── Unity_Package/Assets/AutoImport/  (出力先)
UNITY_EXPORT_SUBPATH = os.path.join(
    "..", "Unity_Package", "Assets", "AutoImport"
)


# ============================================================
# アドオン設定 (Preferences - APIキー保存用)
# ============================================================

class IsekaiPreferences(AddonPreferences):
    bl_idname = "isekai_asset_studio"  # manifest.toml の id と一致させる

    tripo_api_key: StringProperty(
        name="Tripo3D API Key",
        description="Tripo3D の APIキーを入力します",
        default="",
        subtype='PASSWORD'
    ) # type: ignore

    meshy_api_key: StringProperty(
        name="Meshy API Key",
        description="Meshy の APIキーを入力します",
        default="",
        subtype='PASSWORD'
    ) # type: ignore

    comfyui_api_url: StringProperty(
        name="ComfyUI API URL",
        description="ローカルまたはクラウド上のComfyUI APIのエンドポイント (例: http://127.0.0.1:8188)",
        default="http://127.0.0.1:8188",
    ) # type: ignore

    comfyui_workflow_path: StringProperty(
        name="Workflow JSON Path",
        description="ComfyUIから保存したAPI用ワークフロー(.json)のパスを指定します",
        default="",
        subtype='FILE_PATH'
    ) # type: ignore

    def draw(self, context: bpy.types.Context):
        layout = self.layout
        layout.label(text="Text-to-3D API / Backend 設定", icon='CLOUD')
        layout.prop(self, "comfyui_api_url")
        layout.prop(self, "comfyui_workflow_path")
        layout.separator()
        layout.prop(self, "tripo_api_key")
        layout.prop(self, "meshy_api_key")


# ============================================================
# プロパティグループ（シーン共有データ）
# ============================================================

class IsekaiProperties(PropertyGroup):
    """
    Isekai パネルで使用するシーン単位のプロパティ群。
    bpy.context.scene.isekai_props でアクセス可能。
    EnumProperty で操作モードを切り替え、
    role / directive でAIエージェントの仕様を定義する。
    """

    operation_mode: EnumProperty(
        name="操作モード",
        description="実行する操作を選択してください",
        items=[
            (
                'GENERATE_3D',
                "3Dモデル生成",
                "Text-to-3D APIを用いてモデルを生成・インポートする",
                'MESH_CUBE',
                0,
            ),
            (
                'GENERATE_TEX',
                "テクスチャ生成",
                "ダミー画像をダウンロードし、PBRシェーダーノードを自動構築して適用する",
                'TEXTURE',
                1,
            ),
            (
                'EXPORT',
                "Unityへ出力",
                "AIプロファイルJSONとFBXをUnityプロジェクトへエクスポートする",
                'EXPORT',
                2,
            ),
        ],
        default='GENERATE_3D',
    )  # type: ignore

    api_provider: EnumProperty(
        name="API Provider",
        description="使用するAIバックエンドを選択",
        items=[
            ('COMFYUI', "ComfyUI (Local/Hybrid)", "ComfyUIの推論バックエンドを使用します"),
            ('TRIPO', "Tripo3D API", "Tripo3D を使用します"),
            ('MESHY', "Meshy API", "Meshy を使用します"),
        ],
        default='COMFYUI',
    ) # type: ignore

    model_prompt: StringProperty(
        name="3D Prompt",
        description="生成したい3Dモデルの形状を英語で入力",
        default="A low-poly ancient golem with glowing eyes",
    ) # type: ignore

    role: StringProperty(
        name="ロール",
        description="エージェントの役割定義（例: 守護妖怪、商人の長老、境界の番人）",
        default="守護妖怪",
    )  # type: ignore

    directive: StringProperty(
        name="行動指示",
        description=(
            "自然言語による行動プロンプト。\n"
            "例: 神社周囲50mを巡回し、参拝者を保護する。"
        ),
        default="神社の周囲50mを巡回し、参拝者を保護する。",
    )  # type: ignore


# ============================================================
# 通信クラス: VAXIS_ComfyBridge
# ============================================================

class VAXIS_ComfyBridge:
    """
    ComfyUIとの疎結合な通信を担うブリッジクラス。
    PyTorch等の重いライブラリに依存せず、標準ライブラリのみでHTTP通信を行う。
    """
    @staticmethod
    def send_prompt(api_url: str, workflow_path: str, prompt_text: str) -> dict:
        """
        ComfyUIの /prompt エンドポイントに、読み込んだJSONのプロンプトを差し替えてPOSTする。
        """
        if not workflow_path:
            return {"success": False, "error": "Preferences で Workflow JSON のパスを指定してください。"}
            
        if not os.path.exists(workflow_path):
            return {"success": False, "error": f"指定されたJSONファイルが見つかりません: {workflow_path}"}
            
        endpoint = f"{api_url.rstrip('/')}/prompt"
        
        try:
            with open(workflow_path, 'r', encoding='utf-8') as f:
                workflow_data = json.load(f)
        except Exception as e:
            return {"success": False, "error": f"JSONの読み込みに失敗しました: {e}"}
            
        # JSON内の CLIPTextEncode またはプロンプト関係ノードを検索して上書き
        replaced_count = 0
        for node_id, node_info in workflow_data.items():
            if not isinstance(node_info, dict):
                continue
            
            class_type = node_info.get("class_type", "")
            inputs = node_info.get("inputs", {})
            
            # 標準的なテキストエンコーダの処理
            if class_type == "CLIPTextEncode" and "text" in inputs:
                # ユーザーが指定したメインプロンプトで上書き
                inputs["text"] = prompt_text
                replaced_count += 1
                
        # 汎用対応処理: もし CLIPTextEncode が無い場合（特定の3Dバッチノードに直接プロンプトを入れる形式など）
        # 'prompt' 等の名前を持つキーを強引に上書きするフォールバック
        if replaced_count == 0:
            for node_id, node_info in workflow_data.items():
                if isinstance(node_info, dict) and "inputs" in node_info:
                    inputs = node_info["inputs"]
                    for key in ["prompt", "text_prompt", "text"]:
                        if key in inputs and isinstance(inputs[key], str):
                            # 最も長そうな文字列を対象とする（シード値などと混同しないため）
                            inputs[key] = prompt_text
                            replaced_count += 1

        if replaced_count == 0:
            return {"success": False, "error": "ワークフロー内にプロンプト(text)を上書きできるノードが見つかりませんでした。"}

        # 送信用ペイロードの構築
        workflow_payload = {
            "client_id": "vaxis_blender_plugin",
            "prompt": workflow_data
        }
        
        data = json.dumps(workflow_payload).encode('utf-8')
        req = urllib.request.Request(endpoint, data=data, method='POST')
        req.add_header('Content-Type', 'application/json')
        
        try:
            with urllib.request.urlopen(req, timeout=10) as response:
                result = json.loads(response.read().decode('utf-8'))
                return {"success": True, "data": result}
        except urllib.error.URLError as e:
            return {"success": False, "error": f"通信失敗: {e.reason} (サーバー未起動 または URLミス)"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    @staticmethod
    def get_history(api_url: str, prompt_id: str) -> dict:
        """指定されたprompt_idの詳細(履歴)をComfyUIから取得する"""
        endpoint = f"{api_url.rstrip('/')}/history/{prompt_id}"
        req = urllib.request.Request(endpoint, method='GET')
        try:
            with urllib.request.urlopen(req, timeout=5) as response:
                result = json.loads(response.read().decode('utf-8'))
                return {"success": True, "data": result}
        except Exception as e:
            return {"success": False, "error": str(e)}

    @staticmethod
    def download_output(api_url: str, filename: str, subfolder: str = "", folder_type: str = "output") -> dict:
        """ComfyUIの出力ファイルを取得し、一時ファイルとしてローカルに保存する"""
        params = f"filename={urllib.parse.quote(filename)}&type={urllib.parse.quote(folder_type)}"
        if subfolder:
            params += f"&subfolder={urllib.parse.quote(subfolder)}"
        endpoint = f"{api_url.rstrip('/')}/view?{params}"
        
        try:
            req = urllib.request.Request(endpoint, method='GET')
            with urllib.request.urlopen(req, timeout=10) as response:
                content = response.read()
                tmp_dir = tempfile.gettempdir()
                out_path = os.path.join(tmp_dir, f"vaxis_comfy_{filename}")
                with open(out_path, 'wb') as f:
                    f.write(content)
                return {"success": True, "filepath": out_path}
        except Exception as e:
            return {"success": False, "error": str(e)}

# ============================================================
# オペレーター: ComfyUI生成モニタリング (Modal)
# ============================================================

class ISEKAI_OT_comfy_poll_import(Operator):
    """
    ComfyUIへプロンプトを投げた後、非同期的に待機し（UIブロックさせない為にModal使用）、
    生成完了を検知したらダミーから取り出した.glbファイルを自動でBlenderへインポートする。
    """
    bl_idname = "isekai.comfy_poll_import"
    bl_label = "Waiting for ComfyUI generation..."
    
    prompt_id: StringProperty() # type: ignore
    api_url: StringProperty() # type: ignore
    
    _timer = None

    def modal(self, context, event):
        if event.type == 'TIMER':
            res = VAXIS_ComfyBridge.get_history(self.api_url, self.prompt_id)
            if not res.get("success"):
                return {'PASS_THROUGH'}
                
            history_data = res.get("data", {})
            if self.prompt_id in history_data:
                # 完了！出力を抽出
                outputs = history_data[self.prompt_id].get("outputs", {})
                
                target_filename = None
                target_subfolder = ""
                
                # "outputs" のノードを舐めて、3D生成結果のファイル名を探す
                # ComfyUIの形式: {'filename': '...', 'subfolder': '...', 'type': 'output'}
                for node_id, node_output in outputs.items():
                    for k, v in node_output.items():
                        if isinstance(v, list) and len(v) > 0 and isinstance(v[0], dict):
                            file_info = v[0]
                            # glb等であればそれを探す（実際の拡張子に応じる）
                            fname = file_info.get("filename", "")
                            if fname.endswith(".glb") or fname.endswith(".obj"):
                                target_filename = fname
                                target_subfolder = file_info.get("subfolder", "")
                                break
                    if target_filename:
                        break
                            
                self.report({'INFO'}, f"✨ 生成完了検知: {self.prompt_id}")
                
                # 自動インポート
                if target_filename:
                    dl_res = VAXIS_ComfyBridge.download_output(self.api_url, target_filename, target_subfolder)
                    if dl_res.get("success"):
                        # GLTF(.glb) インポートを呼び出す
                        bpy.ops.import_scene.gltf(filepath=dl_res["filepath"])
                        self.report({'INFO'}, f"📦 インポート完了: {target_filename}")
                    else:
                        self.report({'ERROR'}, f"ダウンロード失敗: {dl_res.get('error')}")
                else:
                    self.report({'WARNING'}, "生成結果内にインポート可能な 3D ファイル(.glb/.obj) が見つかりませんでした。")
                
                self.cancel(context)
                return {'FINISHED'}
                
        return {'PASS_THROUGH'}

    def execute(self, context):
        wm = context.window_manager
        # 2.0秒間隔でポーリングタイマーを仕掛ける
        self._timer = wm.event_timer_add(2.0, window=context.window)
        wm.modal_handler_add(self)
        self.report({'INFO'}, "🔄 ComfyUI の生成待機モードに移行しました...")
        return {'RUNNING_MODAL'}
        
    def cancel(self, context):
        wm = context.window_manager
        if self._timer:
            wm.event_timer_remove(self._timer)

# ============================================================
# オペレーター: Text-to-3D 生成 (GENERATE_3D モード)
# ============================================================

class ISEKAI_OT_generate_3d(Operator):
    """
    入力されたテキストプロンプトをもとに、選択したバックエンドAPIに
    3D生成リクエストを送信し、結果のGLBをダウンロード＆インポートする。
    """
    bl_idname = "isekai.generate_3d"
    bl_label = "3Dモデルを自動生成"
    bl_description = "Text-to-3D APIを呼び出してモデルを自動生成します"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: bpy.types.Context):
        props = context.scene.isekai_props
        prefs = context.preferences.addons["isekai_asset_studio"].preferences

        prompt = props.model_prompt

        # --- ComfyUI ブリッジ処理 ---
        if props.api_provider == 'COMFYUI':
            api_url = prefs.comfyui_api_url
            if not api_url:
                self.report({'ERROR'}, "ComfyUI API URL が設定されていません。Preferencesを確認してください。")
                return {'CANCELLED'}
            
            workflow_path = prefs.comfyui_workflow_path
            # Blender形式の // 相対パスが含まれている場合は絶対パスに変換
            if workflow_path.startswith('//'):
                workflow_path = bpy.path.abspath(workflow_path)
            
            self.report({'INFO'}, f"⏳ ComfyUI ({api_url}) へリクエストを送信中...: {prompt}")
            
            # ComfyBridgeを通じてローカルのJSONを読み込んでPOST送信
            result = VAXIS_ComfyBridge.send_prompt(api_url, workflow_path, prompt)
            
            if result.get("success"):
                prompt_id = result['data'].get('prompt_id', 'Unknown')
                self.report({'INFO'}, f"✅ ComfyUI 通信成功！ (Prompt ID: {prompt_id})")
                
                # モーダルの待機オペレーターを呼び出し（UIを固めずに通信を監視する）
                bpy.ops.isekai.comfy_poll_import('INVOKE_DEFAULT', prompt_id=prompt_id, api_url=api_url)
            else:
                self.report({'ERROR'}, f"ComfyUI 通信エラー: {result.get('error')}")
                return {'CANCELLED'}
                
            return {'FINISHED'}

        # --- Cloud API 処理 (Tripo3D / Meshy) ---
        api_key = prefs.tripo_api_key if props.api_provider == 'TRIPO' else prefs.meshy_api_key
        if not api_key:
            self.report({'ERROR'}, f"{props.api_provider} の API Key が設定されていません。")
            return {'CANCELLED'}
        
        self.report({'INFO'}, f"⏳ {props.api_provider} へ生成リクエストを送信開始...: {prompt}")

        # Cloud通信スタブ
        try:
            pass
        except Exception as e:
            self.report({'ERROR'}, f"API通信エラー: {e}")
            return {'CANCELLED'}

        self.report({'INFO'}, f"✅ {props.api_provider} スタブ連携完了 (インポート予約済)")
        return {'FINISHED'}


# ============================================================
# オペレーター: テクスチャ自動生成 (GENERATE_TEX モード)
# ============================================================

class ISEKAI_OT_generate_texture(Operator):
    """
    選択中のメッシュに対し、Pexelsからダミーテクスチャをダウンロードし
    Principled BSDF + TexImage ノードを自動構築・結線して適用する。

    処理フロー:
        1. urllib.request.urlretrieve でダウンロード
        2. ShaderNodeBsdfPrincipled を新規作成
        3. ShaderNodeTexImage を新規作成・画像をロード
        4. TexImage.Color → BSDF.Base Color → Output.Surface をリンク
        5. マテリアルをアクティブオブジェクトに割り当て
    """

    bl_idname = "isekai.generate_texture"
    bl_label = "テクスチャを自動生成"
    bl_description = "ダミー画像をダウンロードし、選択メッシュにPBRマテリアルを自動生成・適用します"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: bpy.types.Context):
        obj = context.active_object

        # --- バリデーション: メッシュオブジェクトが選択されているか確認 ---
        if obj is None or obj.type != 'MESH':
            self.report({'ERROR'}, "メッシュオブジェクトを選択してください。")
            return {'CANCELLED'}

        self.report({'INFO'}, "⏳ テクスチャのダウンロードを開始します...")

        # --- Step 1: ダミー画像のダウンロード ---
        tmp_dir = tempfile.gettempdir()
        img_path = os.path.join(tmp_dir, "isekai_dummy_texture.jpg")

        try:
            urllib.request.urlretrieve(DUMMY_TEXTURE_URL, img_path)
        except Exception as e:
            self.report({'ERROR'}, f"画像のダウンロードに失敗しました: {e}")
            return {'CANCELLED'}

        # --- Step 2: マテリアルの取得または新規作成 ---
        # オブジェクト名をベースに一意のマテリアル名を生成（重複防止）
        mat_name = f"IsekaiMat_{obj.name}"
        mat = bpy.data.materials.get(mat_name)
        if mat is None:
            mat = bpy.data.materials.new(name=mat_name)

        # ノードベースシェーダーを有効化
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        links = mat.node_tree.links

        # 既存ノードをすべてクリア（クリーンな状態からノードグラフを構築）
        nodes.clear()

        # --- Step 3: Principled BSDF ノードの作成 ---
        node_bsdf = nodes.new(type='ShaderNodeBsdfPrincipled')
        node_bsdf.location = (200, 300)
        node_bsdf.label = "IsekaiPBR"

        # --- Step 4: Material Output ノードの作成 ---
        node_output = nodes.new(type='ShaderNodeOutputMaterial')
        node_output.location = (550, 300)

        # --- Step 5: TexImage ノードの作成とテクスチャ読み込み ---
        node_tex = nodes.new(type='ShaderNodeTexImage')
        node_tex.location = (-200, 300)
        node_tex.label = "IsekaiTexture"

        # Blenderの画像データブロックへ読み込み（既存の場合は再利用）
        img_basename = os.path.basename(img_path)
        img = bpy.data.images.get(img_basename)
        if img is None:
            img = bpy.data.images.load(img_path)

        node_tex.image = img

        # --- Step 6: ノードの結線 ---
        # TexImage.Color  ───→ PrincipledBSDF.Base Color
        links.new(node_tex.outputs['Color'], node_bsdf.inputs['Base Color'])
        # PrincipledBSDF.BSDF ─→ MaterialOutput.Surface
        links.new(node_bsdf.outputs['BSDF'], node_output.inputs['Surface'])

        # --- Step 7: マテリアルをオブジェクトに適用 ---
        if obj.data.materials:
            # すでにマテリアルスロットがある場合は最初のスロットを置換
            obj.data.materials[0] = mat
        else:
            # スロットが空の場合は新規追加
            obj.data.materials.append(mat)

        self.report(
            {'INFO'},
            f"✅ テクスチャの生成・適用が完了しました: {obj.name} → {mat_name}",
        )
        return {'FINISHED'}


# ============================================================
# オペレーター: Unity へのエクスポート (EXPORT モード)
# ============================================================

class ISEKAI_OT_export_to_unity(Operator):
    """
    選択中のメッシュオブジェクトについて、
    AIプロファイルJSONと FBX を Unity プロジェクトの AutoImport フォルダへ出力する。

    処理フロー:
        1. .blend ファイルの保存先を bpy.path.abspath('//') で取得
        2. ../Unity_Package/Assets/AutoImport/ フォルダを os.makedirs で作成
        3. スキーマ通りのJSONを utf-8 で書き出し
        4. bpy.ops.export_scene.fbx で選択オブジェクトのFBXを書き出し

    注意:
        .blend ファイルを保存せずに実行すると、基準パスが取得できないため
        エラーを返す。事前に Ctrl+S で保存が必要。
    """

    bl_idname = "isekai.export_to_unity"
    bl_label = "Unityへエクスポート"
    bl_description = "AIプロファイルJSONとFBXをUnityプロジェクトのAutoImportフォルダへ出力します"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: bpy.types.Context):
        props = context.scene.isekai_props
        obj = context.active_object

        # --- バリデーション ---
        if obj is None or obj.type != 'MESH':
            self.report({'ERROR'}, "メッシュオブジェクトを選択してください。")
            return {'CANCELLED'}

        # .blend ファイルの保存先を基準パスとして取得
        blend_base = bpy.path.abspath('//')

        # 未保存ファイルの場合、基準パスが空になるため事前チェック
        if not blend_base or blend_base.strip(os.sep) == '':
            self.report(
                {'ERROR'},
                "先に .blend ファイルを保存してください（Ctrl+S）。"
                "パスの基準点として必要です。",
            )
            return {'CANCELLED'}

        # --- エクスポート先フォルダの決定と作成 ---
        export_dir = os.path.normpath(
            os.path.join(blend_base, UNITY_EXPORT_SUBPATH)
        )
        os.makedirs(export_dir, exist_ok=True)

        asset_name = obj.name

        # --- Step 1: AIプロファイルJSONのエクスポート ---
        # 仕様書で定義されたスキーマ（JSONブリッジ）に完全一致させる
        json_data = {
            "asset_name": asset_name,
            "agent_profile": {
                "role": props.role,
                "directive": props.directive,
            },
        }

        json_path = os.path.join(export_dir, f"{asset_name}.json")

        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(json_data, f, ensure_ascii=False, indent=2)

        self.report({'INFO'}, f"📄 JSON出力完了: {json_path}")

        # --- Step 2: FBXのエクスポート ---
        fbx_path = os.path.join(export_dir, f"{asset_name}.fbx")

        try:
            bpy.ops.export_scene.fbx(
                filepath=fbx_path,
                use_selection=True,           # 選択オブジェクトのみ出力
                embed_textures=False,         # テクスチャは参照形式で管理
                apply_scale_options='FBX_SCALE_ALL',  # Unity向けスケール正規化
                axis_forward='-Z',            # Unity座標系への変換
                axis_up='Y',
            )
        except Exception as e:
            self.report(
                {'WARNING'},
                f"FBXエクスポート中にエラーが発生しました: {e}",
            )
            return {'CANCELLED'}

        self.report({'INFO'}, f"📦 FBX出力完了: {fbx_path}")
        self.report(
            {'INFO'},
            f"🚀 [{asset_name}] のデプロイパッケージ出力が完了しました！"
            f" → {export_dir}",
        )
        return {'FINISHED'}


# ============================================================
# UIパネル: VIEW_3D サイドバー「Isekai」タブ
# ============================================================

class ISEKAI_PT_main_panel(Panel):
    """
    3D ビューポートの右サイドバー（Nキーパネル）に
    「Isekai」タブとして表示されるメインコントロールパネル。

    レイアウト構成:
        [ヘッダー]  MobilisFrontier Pipeline ロゴ領域
        [モード]    GENERATE / EXPORT ラジオボタン
        [定義]      role / directive テキストフィールド
        [状態]      選択中オブジェクト表示
        [実行]      モードに応じたアクションボタン
        [フッター]  バージョン情報
    """

    bl_label = "🏯 Isekai Asset Studio"
    bl_idname = "ISEKAI_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Isekai'  # サイドバーのタブ名

    def draw(self, context: bpy.types.Context):
        layout = self.layout
        props = context.scene.isekai_props
        obj = context.active_object

        # --- ヘッダー: プロジェクト情報 ---
        header = layout.box()
        row = header.row()
        row.label(text="MobilisFrontier Pipeline", icon='WORLD')
        sub = header.row()
        sub.label(text="Zero-Code AI Deploy", icon='LIGHT')

        layout.separator()

        # --- 操作モード選択 ---
        layout.label(text="操作モード:", icon='SETTINGS')
        row = layout.row(align=True)
        row.prop(props, 'operation_mode', expand=True)

        layout.separator()

        # --- AIエージェント定義セクション ---
        section = layout.box()
        section.label(text="AIエージェント定義", icon='ARMATURE_DATA')
        section.prop(props, 'role', icon='USER')
        section.prop(props, 'directive', icon='OUTLINER_DATA_FONT')

        layout.separator()

        # --- アクティブオブジェクト状態表示 ---
        info_box = layout.box()
        if obj and obj.type == 'MESH':
            info_box.label(text=f"対象: {obj.name}", icon='MESH_DATA')
        else:
            info_box.alert = True
            info_box.label(text="Mesh オブジェクトを選択してください", icon='ERROR')

        layout.separator()

        # --- モード別アクションボタン ---
        if props.operation_mode == 'GENERATE_3D':
            # Text-to-3D生成時のUI
            section3d = layout.box()
            section3d.label(text="生成バックエンド:", icon='CLOUD')
            section3d.prop(props, 'api_provider', text="")
            section3d.prop(props, 'model_prompt', icon='SYNTAX_OFF')
            
            layout.separator()
            col = layout.column(align=True)
            col.scale_y = 1.6
            col.operator(
                "isekai.generate_3d",
                text="✨  3Dモデルを自動生成",
                icon='MESH_CUBE',
            )

        elif props.operation_mode == 'GENERATE_TEX':
            col = layout.column(align=True)
            col.scale_y = 1.6
            col.operator(
                "isekai.generate_texture",
                text="✨  テクスチャを自動生成",
                icon='TEXTURE',
            )

        elif props.operation_mode == 'EXPORT':
            col = layout.column(align=True)
            col.scale_y = 1.6
            col.operator(
                "isekai.export_to_unity",
                text="🚀  Unity へデプロイ",
                icon='EXPORT',
            )

        layout.separator()

        # --- フッター: バージョン情報 ---
        footer = layout.box()
        footer.label(text="v1.0.0 — IsekaiPipeline", icon='INFO')


# ============================================================
# Blender Extension 登録 / 解除
# ============================================================

# 登録対象クラスのリスト（依存順に並べること）
CLASSES = (
    IsekaiPreferences,
    IsekaiProperties,
    ISEKAI_OT_comfy_poll_import,
    ISEKAI_OT_generate_3d,
    ISEKAI_OT_generate_texture,
    ISEKAI_OT_export_to_unity,
    ISEKAI_PT_main_panel,
)


def register():
    """
    Extension の登録処理。
    Blender 起動時またはアドオン有効化時に呼び出される。
    """
    for cls in CLASSES:
        bpy.utils.register_class(cls)

    # シーンへのプロパティグループ登録
    # bpy.context.scene.isekai_props でアクセス可能になる
    bpy.types.Scene.isekai_props = PointerProperty(type=IsekaiProperties)

    print("[Isekai Asset Studio] 起動完了 — MobilisFrontier Pipeline へようこそ。")


def unregister():
    """
    Extension の解除処理。
    アドオン無効化時に呼び出される。
    プロパティグループを削除してシーンデータを正常にクリーンアップする。
    """
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)

    # プロパティグループの解除（シーンデータのクリーンアップ）
    del bpy.types.Scene.isekai_props

    print("[Isekai Asset Studio] 正常に終了しました。")


if __name__ == "__main__":
    # Blender スクリプトエディタから直接実行する場合のエントリーポイント
    register()
